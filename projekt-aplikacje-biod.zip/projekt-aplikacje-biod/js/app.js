// Stan aplikacji (Pusta baza początkowa)
let attractions = [];
let myPlan = [];
let chartInstance = null;

// Pobranie elementów DOM
const gridContainer = document.getElementById('attractions-grid');
const searchInput = document.getElementById('search-input');
const filterSelect = document.getElementById('filter-select');
const sortSelect = document.getElementById('sort-select');

const planTbody = document.getElementById('plan-tbody');
const totalCostEl = document.getElementById('total-cost');
const addForm = document.getElementById('add-attraction-form');
const formMessage = document.getElementById('form-message');

// Inicjalizacja zdarzeń po załadowaniu drzewa DOM
document.addEventListener('DOMContentLoaded', () => {
    renderAttractions();
    updateDashboard();
    initChart();

    if (searchInput) searchInput.addEventListener('input', renderAttractions);
    if (filterSelect) filterSelect.addEventListener('change', renderAttractions);
    if (sortSelect) sortSelect.addEventListener('change', renderAttractions);
    if (addForm) addForm.addEventListener('submit', handleAddAttraction);
});

// Zabezpieczenie przed atakami XSS
function escapeHTML(str) {
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// 1. Renderowanie kafelków z atrakcjami (Sekcja 2)
function renderAttractions() {
    if (!gridContainer) return;

    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const typeFilter = filterSelect ? filterSelect.value : 'all';

    let filtered = attractions.filter(item => {
        const matchesSearch = item.name.toLowerCase().includes(query) || item.city.toLowerCase().includes(query);
        const matchesType = typeFilter === 'all' || item.type === typeFilter;
        return matchesSearch && matchesType;
    });

    if (sortSelect) {
        if (sortSelect.value === 'price-asc') {
            filtered.sort((a, b) => a.cost - b.cost);
        } else if (sortSelect.value === 'price-desc') {
            filtered.sort((a, b) => b.cost - a.cost);
        } else if (sortSelect.value === 'rating-desc') {
            filtered.sort((a, b) => b.rating - a.rating);
        }
    }

    gridContainer.innerHTML = '';

    if (filtered.length === 0) {
        gridContainer.innerHTML = '<p class="empty-info">Brak wyników w bazie. Dodaj nową atrakcję w Sekcji 5.</p>';
        return;
    }

    filtered.forEach(item => {
        const card = document.createElement('div');
        card.className = 'attraction-card';

        const safeName = escapeHTML(item.name);
        const safeCity = escapeHTML(item.city);
        const imgHtml = item.img ? `<img src="${escapeHTML(item.img)}" alt="${safeName}">` : '';

        card.innerHTML = `
            ${imgHtml}
            <h3>${safeName}</h3>
            <p><strong>Miejscowość:</strong> ${safeCity}</p>
            <p><strong>Cena:</strong> ${item.cost === 0 ? 'Darmowe' : item.cost.toFixed(2) + ' PLN'} | <strong>Ocena:</strong> ${item.rating}/5</p>
            <div class="card-btns">
                <button type="button" class="btn-add-plan">Dodaj do planu</button>
                <button type="button" class="btn-like">Lubię to! (${item.likes})</button>
            </div>
        `;

        // Obsługa dodawania do planu wycieczki
        card.querySelector('.btn-add-plan').addEventListener('click', () => addToPlan(item.id));
        
        // Obsługa polubienia z krótkim efektem wizualnym
        const likeBtn = card.querySelector('.btn-like');
        likeBtn.addEventListener('click', () => {
            item.likes += 1;
            
            // Efekt wizualny na przycisku
            likeBtn.textContent = "Polubiono!";
            likeBtn.style.backgroundColor = "#ff217e";
            likeBtn.style.color = "#ffffff";

            // Powrót do standardowego wyglądu po 1 sekundzie
            setTimeout(() => {
                renderAttractions();
            }, 3000);
        });

        gridContainer.appendChild(card);
    });
}

// 2. Dashboard i statystyki (Sekcja 3)
function updateDashboard() {
    const totalCount = attractions.length;
    const freeCount = attractions.filter(a => a.cost === 0).length;
    const avgCost = totalCount > 0 ? (attractions.reduce((sum, a) => sum + a.cost, 0) / totalCount).toFixed(2) : 0;

    const elTotal = document.getElementById('stat-total');
    const elAvg = document.getElementById('stat-avg-cost');
    const elFree = document.getElementById('stat-free-count');

    if (elTotal) elTotal.textContent = totalCount;
    if (elAvg) elAvg.textContent = `${avgCost} PLN`;
    if (elFree) elFree.textContent = freeCount;

    if (chartInstance) {
        updateChartData();
    }
}

function initChart() {
    const canvas = document.getElementById('attractionsChart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const counts = getTypeCounts();

    chartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Zabytki', 'Natura', 'Rozrywka'],
            datasets: [{
                label: 'Liczba atrakcji',
                data: [counts.zabytek, counts.natura, counts.rozrywka],
                backgroundColor: ['#E8A5A5', '#84B082', '#F9C784']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1 } }
            }
        }
    });
}

function updateChartData() {
    const counts = getTypeCounts();
    chartInstance.data.datasets[0].data = [counts.zabytek, counts.natura, counts.rozrywka];
    chartInstance.update();
}

function getTypeCounts() {
    return {
        zabytek: attractions.filter(a => a.type === 'zabytek').length,
        natura: attractions.filter(a => a.type === 'natura').length,
        rozrywka: attractions.filter(a => a.type === 'rozrywka').length
    };
}

// 3. Tabela z planem wycieczki (Sekcja 4)
function addToPlan(id) {
    const attraction = attractions.find(a => a.id === id);
    if (attraction) {
        myPlan.push(attraction);
        renderPlanTable();
    }
}

function removeFromPlan(index) {
    myPlan.splice(index, 1);
    renderPlanTable();
}

function renderPlanTable() {
    if (!planTbody || !totalCostEl) return;

    planTbody.innerHTML = '';
    let total = 0;

    if (myPlan.length === 0) {
        planTbody.innerHTML = '<tr><td colspan="4" style="text-align: center;">Brak miejsc w planie wycieczki.</td></tr>';
        totalCostEl.textContent = '0';
        return;
    }

    myPlan.forEach((item, index) => {
        total += item.cost;
        const tr = document.createElement('tr');

        tr.innerHTML = `
            <td>${escapeHTML(item.name)}</td>
            <td>${escapeHTML(item.city)}</td>
            <td>${item.cost === 0 ? 'Darmowe' : item.cost.toFixed(2) + ' PLN'}</td>
            <td><button class="btn-delete" type="button">Usuń</button></td>
        `;

        tr.querySelector('.btn-delete').addEventListener('click', () => removeFromPlan(index));
        planTbody.appendChild(tr);
    });

    totalCostEl.textContent = total.toFixed(2);
}

// 4. Obsługa i walidacja formularza (Sekcja 5)
function handleAddAttraction(e) {
    e.preventDefault();
    hideMessage();

    const nameEl = document.getElementById('form-name');
    const cityEl = document.getElementById('form-city');
    const typeEl = document.getElementById('form-type');
    const costEl = document.getElementById('form-cost');
    const ratingEl = document.getElementById('form-rating');
    const imgEl = document.getElementById('form-img');
    const emailEl = document.getElementById('form-email');
    const termsEl = document.getElementById('form-terms');

    const name = nameEl ? nameEl.value.trim() : '';
    const city = cityEl ? cityEl.value.trim() : '';
    const type = typeEl ? typeEl.value : '';
    const costRaw = costEl ? costEl.value : '';
    const ratingRaw = ratingEl ? ratingEl.value : '';
    const imgRaw = imgEl ? imgEl.value.trim() : '';
    const email = emailEl ? emailEl.value.trim() : '';
    const terms = termsEl ? termsEl.checked : false;

    const cost = parseFloat(costRaw);
    const rating = parseFloat(ratingRaw);

    if (!name || name.length < 3) {
        showMessage("Nazwa atrakcji musi mieć co najmniej 3 znaki.", "error");
        return;
    }

    if (!city) {
        showMessage("Miejscowość jest wymagana.", "error");
        return;
    }

    if (!type) {
        showMessage("Proszę wybrać typ atrakcji z listy.", "error");
        return;
    }

    if (isNaN(cost) || cost < 0 || cost > 10000) {
        showMessage("Koszt musi być wartością od 0 do 10000 PLN.", "error");
        return;
    }

    if (isNaN(rating) || rating < 1 || rating > 5) {
        showMessage("Ocena musi mieścić się w przedziale 1-5.", "error");
        return;
    }

    if (!email || !email.includes('@')) {
        showMessage("Podaj poprawny adres e-mail.", "error");
        return;
    }

    if (!terms) {
        showMessage("Musisz zaakceptować oświadczenie.", "error");
        return;
    }

    const newAttraction = {
        id: Date.now(),
        name: name,
        city: city,
        cost: cost,
        rating: rating,
        type: type,
        img: imgRaw !== "" ? imgRaw : null,
        likes: 0
    };

    attractions.push(newAttraction);
    renderAttractions();
    updateDashboard();

    showMessage("Atrakcja pomyślnie dodana!", "success");
    addForm.reset();
}

function showMessage(msg, type) {
    if (!formMessage) return;
    formMessage.textContent = msg;
    formMessage.className = `message-box ${type}`;
}

function hideMessage() {
    if (!formMessage) return;
    formMessage.textContent = '';
    formMessage.className = 'message-box hidden';
}